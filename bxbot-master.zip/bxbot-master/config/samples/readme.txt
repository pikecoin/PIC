Sample BX-bot Configurations
============================

Each folder contains sample config for running against a particular Exchange.
 
Copy the sample XML files for the chosen exchange into the ../config folder.
