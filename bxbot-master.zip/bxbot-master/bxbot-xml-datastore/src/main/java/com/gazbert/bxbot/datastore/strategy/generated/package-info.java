/**
 * <h2>Auto-generated JAXB Classes for Trading Strategy Configuration</h2>
 *
 * <p>
 * You don't need to regenerate these classes unless you plan on changing the configuration subsystem.
 * </p>
 *
 * <p>
 * The classes were generated using
 * <a href="http://docs.oracle.com/javase/8/docs/technotes/tools/unix/xjc.html">xjc</a> and the strategies.xsd
 * </p>
 * 
 * @author gazbert
 */
package com.gazbert.bxbot.datastore.strategy.generated;