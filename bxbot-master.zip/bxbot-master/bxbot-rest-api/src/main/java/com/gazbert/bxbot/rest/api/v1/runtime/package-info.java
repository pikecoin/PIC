/**
 * <h2>BX-bot Runtime REST API</h2>
 * <p>
 * This is the REST API for stopping/starting the bot and querying the its runtime status.
 *
 * @author gazbert
 * @since 1.0
 */
package com.gazbert.bxbot.rest.api.v1.runtime;