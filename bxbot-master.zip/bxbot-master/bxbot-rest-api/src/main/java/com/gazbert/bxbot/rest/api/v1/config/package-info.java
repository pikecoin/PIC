/**
 * <h2>BX-bot Configuration REST API</h2>
 * <p>
 * This is v1 of the REST API for administering the bot's configuration.
 *
 * @author gazbert
 * @since 1.0
 */
package com.gazbert.bxbot.rest.api.v1.config;